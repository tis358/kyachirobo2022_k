/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <stdbool.h>
#include <math.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
enum _sState {stand_by,origin,working,error,homing} sState;
enum _ctrlMode {pos_cmd_mode, vel_cmd_mode, cur_cmd_mode, vol_cmd_mode} ctrlMode;
typedef enum _M_num{M0,M1,M2,M3} M_num;

#define pulse2roll_0  (1.0f /291635.2f)
#define pulse2rad_0 ((1.0f /291635.2f)*2.0f*M_PI)
#define pulse2deg_0 ((1.0f /291635.2f)*360.0f)
#define pulse2rad_S_0 ((1.0f /291635.2f)*2.0f*M_PI*125.0f)
#define pulse2rev_0 ((1.0f /291635.2f)*125.0f)
/*  old parameter
#define pulse2roll_m0  (1.0f /5996544.0f) //972034 @0.5r
#define pulse2rad_m0 ((1.0f /5996544.0f)*2.0f*M_PI)
#define pulse2deg_m0 ((1.0f /5996544.0f)*360.0f)
#define pulse2rad_S_m0 ((1.0f /5996544.0f)*2.0f*M_PI*125.0f)
#define pulse2rev_m0 ((1.0f /5996544.0f)*125.0f)

#define pulse2roll_m1  (1.0f /1749811.2f) //561418 @0.25r
#define pulse2rad_m1 ((1.0f /1749811.2f)*2.0f*M_PI)
#define pulse2deg_m1 ((1.0f /1749811.2f)*360.0f)
#define pulse2rad_S_m1 ((1.0f /1749811.2f)*2.0f*M_PI*125.0f)
#define pulse2rev_m1 ((1.0f /1749811.2f)*125.0f)
*/

#define pulse2encRev (1.0f/2048.0f) //depends on rotary encoder setting
#define pulse2encRot (125.0f/2048.0f) //8mSec period sampling

#define pulse2roll_m0  (0.5f /972034.0f) //972034 @0.5r
#define pulse2rad_m0 ((0.5f /972034.0f)*2.0f*M_PI)
#define pulse2deg_m0 ((0.5f /972034.0f)*360.0f)
#define pulse2rad_S_m0 ((0.5f /972034.0f)*2.0f*M_PI*125.0f)
#define pulse2rev_m0 ((0.5f /972034.0f)*125.0f)

#define pulse2roll_m1  (0.25f /561418.0f) //561418 @0.25r
#define pulse2rad_m1 ((M_PI_2 /561418.0f))
#define pulse2deg_m1 ((0.25f /561418.0f)*360.0f)
#define pulse2rad_S_m1 ((M_PI_2 /561418.0f)*125.0f)
#define pulse2rev_m1 ((0.25f /561418.0f)*125.0f)

#define pulse2roll_m2  (1.0f /737280.0f) //122825, 29.98657 ->30
#define pulse2rad_m2 ((1.0f /737280.0f)*2.0f*M_PI)
#define pulse2deg_m2 ((1.0f /737280.0f)*360.0f)
#define pulse2rad_S_m2 ((1.0f /737280.0f)*2.0f*M_PI*125.0f)
#define pulse2rev_m2 ((1.0f /737280.0f)*125.0f)

#define pulse2roll_m3 (1.0f /122880.0f)
#define pulse2rad_m3 ((1.0f /122880.0f)*2.0f*M_PI)
#define pulse2mm_m3  (1.0f /3072.0f)
#define pulse2rad_S_m3 ((1.0f /122880.0f)*2.0f*M_PI*125.0f)
#define pulse2mm_S_m3 ((1.0f /3072.0f)*125.0f)

#define rad2deg (180.0f/M_PI)

typedef struct _M_Param{
    float Re;
    float Ke;
    float Vs;
    float Kp_P;
    float Kp_V;
    float Ki_V;
    float pls2Rad;
    float Ts_p;
    float Ts_n;
    float plimit_min;
    float plimit_max;
    float vlimit_min;
    float vlimit_max;
    float climit_min;
    float climit_max;
} M_Param;

//parameter		Re		Ke			Vs		Kp_P	Kp_V	Ki_V	p2r		+Ts		-Ts		Pmin		Pmax	Vmin	Vmax	Cmin	Cmax
M_Param p_0 = {	0.50f,	1.1494f,	0.0f,	30.0f,	5.0f,	0.005f,	0.0f,	0.0f,	0.0f,	-100.0f,	100.0f,	-9.0f,	9.0f,	-10.0f,	10.0f};
//M_Param pM0 = {	0.48f,	8.1953f,	0.0f,	8.0f,	80.0f,	0.00004f,	0.0f,	0.0f,	0.0f,	-100.0f,	100.0f,	-9.0f,	9.0f,	-40.0f,	40.0f};
//M_Param pM1 = {	0.50f,	6.2965f,	0.0f,	0.0f,	35.0f,	0.00002f,	0.0f,	0.0f,	0.0f,	-100.0f,	100.0f,	-9.0f,	9.0f,	-10.0f,	10.0f};
M_Param pM0 = {	0.48f,	2.6569f,	0.0f,	2.594f,	25.94f,	0.000026f,	0.0f,	0.0f,	0.0f,	-1.0f,	3.14f,	-9.0f,	9.0f,	-40.0f,	40.0f};
M_Param pM1 = {	0.50f,	8.0808f,	0.0f,	8.0f,	44.92f,	0.000026f,	0.0f,	0.0f,	0.0f,	-1.0f,	3.14f,	-9.0f,	9.0f,	-10.0f,	10.0f};
M_Param pM2 = {	1.95f,	2.3711f,	0.0f,	20.0f,	6.0f,	0.00001f,	0.0f,	0.0f,	0.0f,	-100.0f,	100.0f,	-9.0f,	9.0f,	-10.0f,	10.0f};
M_Param pM3 = {	1.81f,	0.0685f,	0.0f,	10.0f,	0.3f,	0.000005f,	0.0f,	0.0f,	0.0f,	-300.0f,	300.0f,	-500.0f,	500.0f,	-10.0f,	10.0f};



/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

DAC_HandleTypeDef hdac;

I2C_HandleTypeDef hi2c2;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;
TIM_HandleTypeDef htim5;
TIM_HandleTypeDef htim6;
TIM_HandleTypeDef htim8;

UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */
float vBat = 0.0;
volatile float CMD_pos[4] = {0};//rad
volatile float CMD_rev[4] = {0};
volatile float CMD_vel[4] = {0};//rad/sec
volatile float CMD_rot[4] = {0};
volatile float CMD_cur[4] = {0};//ampere
volatile float CMD_vol[4] = {0};//voltage

float err_pos[4] = {0};
float err_vel[4] = {0};
float err_cur[4] = {0};

volatile float V_BAT_raw = 0.0f;
volatile float V_BAT_act = 0.0f;
volatile uint16_t V_VR[2] = {0};

int16_t enc_value[4] = {0};
int32_t enc_pos_raw[4] = {0};
float enc_rev[4] = {0.0f};
float enc_pos[4] = {0.0f};
int16_t enc_diff_raw[4] = {0};
float enc_speed_raw[4] = {0.0f};
float enc_rot[4] = {0.0f};
float enc_speed[4] = {0.0f};
uint32_t origin_evt = 0;
uint32_t homing_evt = 0;
//const float origin_pos[4] = {3.141592, 0.0, 0.0, 0.0};
const float home_pos[4] = {M_PI_2, 1.2f, 4.0, 48e0.0};

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM4_Init(void);
static void MX_TIM5_Init(void);
static void MX_TIM8_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_I2C2_Init(void);
static void MX_DAC_Init(void);
static void MX_TIM6_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
int _write(int file, char *ptr, int len){
  int DataIdx;
  for(DataIdx=0; DataIdx<len; DataIdx++)
  {
    ITM_SendChar(*ptr++);
  }
  return len;
}

void ADC1_ScanRead(void){
	uint16_t ADC_Raw[3] = {0};
	//ADC Execution
	for(uint32_t i=0; i<3;i++){
		if (HAL_ADC_Start(&hadc1) != HAL_OK){Error_Handler();} /* Start Conversation Error */
		if (HAL_ADC_PollForConversion(&hadc1, 1) != HAL_OK){Error_Handler();}  /* End Of Conversion flag not set on time */
		ADC_Raw[i] = HAL_ADC_GetValue(&hadc1);
	}
	V_BAT_raw = ((3.3f /4096.0f)*4.333f) *(float)ADC_Raw[0];
	V_VR[0] = ADC_Raw[1];
	V_VR[1] = ADC_Raw[2];
	return;
}

void calc_vBAT(void){
	static float vBAT_pst = 0.0;
	V_BAT_act = 0.99 *vBAT_pst + (1.0-0.99)*V_BAT_raw;
	vBAT_pst = V_BAT_act;
	return;
}

int32_t V_BAT_check(){
	if(V_BAT_act < 12.0f){return -1;}
	else if(V_BAT_act > 14.9f){return -2;}
	return 0;
}

//motor driver profile
/*
#define cPWM0_p (-8)
#define cPWM1_p (+8)
#define cPWM0_n (+9)
#define cPWM1_n (-9)
#define pwm_db 34 //12.0us
*/

const int32_t cPWM0_p[4] = {-12,- 7,-10,-11};
const int32_t cPWM1_p[4] = { 11,  7, 10, 10};
const int32_t cPWM0_n[4] = { 11, 11, 10, 10};
const int32_t cPWM1_n[4] = {-12,-11,-10,-11};
const int32_t pwm_db[4] ={34,34,34,34};

void mDrive(M_num motorNum, float vOUT){

	float out_duty = 0.0f;
	int16_t out_val = 0;
	int16_t pwm_ideal[2] = {0};
	int16_t pwm_val[2] = {0};
	int32_t mSEL = (int32_t)motorNum;

	out_duty = vOUT /V_BAT_act;
	out_val = (int16_t)(255.0f *out_duty);

	pwm_ideal[0] = 256 -out_val;
	pwm_ideal[1] = 256 +out_val;

	if		(pwm_ideal[0] <   0 +pwm_db[mSEL]) {pwm_ideal[0] =  0 +pwm_db[mSEL];} //0v saturation L output
	else if	(pwm_ideal[0] > 512 -pwm_db[mSEL]) {pwm_ideal[0] =512 -pwm_db[mSEL];} //Vbatt saturation L output
	if		(pwm_ideal[1] <   0 +pwm_db[mSEL]) {pwm_ideal[1] =  0 +pwm_db[mSEL];}	//0v saturation R output
	else if	(pwm_ideal[1] > 512 -pwm_db[mSEL]) {pwm_ideal[1] =512 -pwm_db[mSEL];} //Vbatt saturation R output

	//PWM OUTPUT Compensation

	if(out_val > 0){
		pwm_val[0] = pwm_ideal[0] +cPWM0_p[mSEL]; //PWM 0(L) OUT
		pwm_val[1] = pwm_ideal[1] +cPWM1_p[mSEL]; //PWM 1(R) OUT
	}
	else{
		pwm_val[0] = pwm_ideal[0] +cPWM0_n[mSEL]; //PWM 0(L) OUT
		pwm_val[1] = pwm_ideal[1] +cPWM1_n[mSEL]; //PWM 1(R) OUT
	}

	switch(motorNum){
		case M0:
			__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, pwm_val[0]);
			__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, pwm_val[1]);
		break;

		case M1:
			__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, pwm_val[0]);
			__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4, pwm_val[1]);
		break;

		case M2:
			__HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_1, pwm_val[0]);
			__HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_2, pwm_val[1]);
		break;

		case M3:
			__HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_3, pwm_val[0]);
			__HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_4, pwm_val[1]);
		break;
	}
	return;
}
/*
int32_t (*enc_diff[4])() = {
		get_diff_enc0,
		get_diff_enc1,
		get_diff_enc2,
		get_diff_enc3
};*/

void get_enc_status(){
	//get each encoder value
	enc_value[0] = (int16_t)(TIM2 -> CNT);
	enc_value[1] = (int16_t)(TIM3 -> CNT);
	enc_value[2] = (int16_t)(TIM4 -> CNT);
	enc_value[3] = (int16_t)(TIM5 -> CNT);

	//get each encoder difference
	static uint16_t enc_buff[4];

	enc_diff_raw[0] = enc_value[0] -enc_buff[0];
	enc_diff_raw[1] = enc_value[1] -enc_buff[1];
	enc_diff_raw[2] = enc_value[2] -enc_buff[2];
	enc_diff_raw[3] = enc_value[3] -enc_buff[3];

	enc_buff[0] = enc_value[0];
	enc_buff[1] = enc_value[1];
	enc_buff[2] = enc_value[2];
	enc_buff[3] = enc_value[3];

	//get each encoder position
	enc_pos_raw[0] += enc_diff_raw[0];
	enc_pos_raw[1] += enc_diff_raw[1];
	enc_pos_raw[2] += enc_diff_raw[2];
	enc_pos_raw[3] += enc_diff_raw[3];
}

void pulse2rev(){
	enc_rev[0] = (float)enc_pos_raw[0] *pulse2encRev;
	enc_rev[1] = (float)enc_pos_raw[1] *pulse2encRev;
	enc_rev[2] = (float)enc_pos_raw[2] *pulse2encRev;
	enc_rev[3] = (float)enc_pos_raw[3] *pulse2encRev;
}

void pulse2rot(){
	enc_rot[0] = enc_speed_raw[0] *pulse2encRot;
	enc_rot[1] = enc_speed_raw[1] *pulse2encRot;
	enc_rot[2] = enc_speed_raw[2] *pulse2encRot;
	enc_rot[3] = enc_speed_raw[3] *pulse2encRot;
}

void CMD_pos2rev(){
	CMD_pos[0] =
}

void CMD_vel2rot(){

}

void pulse2pos(){ //unit:rad
	enc_pos[0] = (float)enc_pos_raw[0] *pulse2rad_m0; //*pulse2rad_0;
	enc_pos[1] = (float)enc_pos_raw[1] *pulse2rad_m1;
	enc_pos[2] = (float)enc_pos_raw[2] *pulse2rad_m2;
	enc_pos[3] = (float)enc_pos_raw[3] *pulse2mm_m3; //mm
}

void pulse2vel(){ //unit:rad/sec
	enc_speed[0] = enc_speed_raw[0] *pulse2rad_S_m0; //*pulse2rad_S_0;
	enc_speed[1] = enc_speed_raw[1] *pulse2rad_S_m1;
	enc_speed[2] = enc_speed_raw[2] *pulse2rad_S_m2;
	enc_speed[3] = enc_speed_raw[3] *pulse2mm_S_m3; //mm/sec
}

void enc_setRadPos(M_num motorNum, float pos){
	switch(motorNum){
		case M0:
			enc_pos_raw[0]=(int32_t)(pos*(1.0f/pulse2rad_m0));
		break;

		case M1:
			enc_pos_raw[1]=(int32_t)(pos*(1.0f/pulse2rad_m1));
		break;

		case M2:
			enc_pos_raw[2]=(int32_t)(pos*(1.0f/pulse2rad_m2));
		break;

		case M3:
			enc_pos_raw[3]=(int32_t)(pos*(1.0f/pulse2mm_m3));
		break;
	}
	return;
}

#define homePos_0 0.02 //rad
#define homePos_1 0.523599 //rad
#define homePos_2 0 //rad
#define homePos_3 0 //mm

union{
	uint8_t whole;
	struct{
		uint8_t m0 : 2; //initialized member
		uint8_t m1 : 2;
		uint8_t m2 : 2;
		uint8_t m3 : 2;
	}idv;
}homing_status;

int32_t pos_tmp[4] = {0};

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin){

	if(sState == origin){
		if(GPIO_Pin == GPIO_PIN_12){
			switch(homing_status.idv.m0){
			case 0x00:
				pos_tmp[0] = enc_pos_raw[0];
				if(origin_evt == 0x00){
					homing_status.idv.m0 = 0x01;
				}
				break;
			case 0x01:
				if(origin_evt == 0x02){
					enc_setRadPos(M0,homePos_0);
					homing_status.idv.m0 = 0x03;
				}
				break;
			}
		}
		if(GPIO_Pin == GPIO_PIN_13){
			switch(homing_status.idv.m1){
			case 0x00:
				pos_tmp[1] = enc_pos_raw[1];
				if(origin_evt == 0x04){
					homing_status.idv.m1 = 0x01;
				}
				break;
			case 0x01:
				if(origin_evt == 0x06){
					enc_setRadPos(M1,homePos_1);
					homing_status.idv.m1 = 0x03;
				}
				break;
			}
		}
		if(GPIO_Pin == GPIO_PIN_14){
			switch(homing_status.idv.m2){
			case 0x00:
				pos_tmp[2] = enc_pos_raw[2];
				if(origin_evt == 0x08){
					homing_status.idv.m2 = 0x01;
				}
				break;
			case 0x01:
				if(origin_evt == 0x0a){
					enc_setRadPos(M2,homePos_2);
					homing_status.idv.m2 = 0x03;
				}
				break;
			}
		}
		if(GPIO_Pin == GPIO_PIN_15){
			switch(homing_status.idv.m3){
			case 0x00:
				pos_tmp[3] = enc_pos_raw[3];
				if(origin_evt == 0x0c){
					homing_status.idv.m3 = 0x01;
				}
				break;
			case 0x01:
				if(origin_evt == 0x0e){
					enc_setRadPos(M3,homePos_3);
					homing_status.idv.m3 = 0x03;
				}
				break;
			}
		}
	}
}



void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim){
    if (htim == &htim6){
    	//HAL_DAC_SetValue(&hdac, DAC_CHANNEL_1, DAC_ALIGN_12B_R, 0);

    	//get essential status
    	get_enc_status();
    	ADC1_ScanRead();
    	calc_vBAT();

    	//calc encoder velocity
    	static int32_t enc_diff_tmp[4][8] = {{0}};
    	static uint32_t e_add_t = 0;
    	static uint32_t e_add_b = 1;
    	static int32_t enc_diff_sum[4] = {0};

    	//4-8 length ring buffer_proc1
    	enc_diff_tmp[0][e_add_t] = enc_diff_raw[0];
    	enc_diff_tmp[1][e_add_t] = enc_diff_raw[1];
    	enc_diff_tmp[2][e_add_t] = enc_diff_raw[2];
    	enc_diff_tmp[3][e_add_t] = enc_diff_raw[3];

    	enc_diff_sum[0] += enc_diff_tmp[0][e_add_t];
    	enc_diff_sum[1] += enc_diff_tmp[1][e_add_t];
    	enc_diff_sum[2] += enc_diff_tmp[2][e_add_t];
    	enc_diff_sum[3] += enc_diff_tmp[3][e_add_t];

    	//low-pass process
    	static float enc_speed_raw_prev[4] = {0.0f};
    	enc_speed_raw[0] = 0.8f*enc_speed_raw_prev[0] + (1.0f-0.8f)*(float)enc_diff_sum[0];
    	enc_speed_raw[1] = 0.8f*enc_speed_raw_prev[1] + (1.0f-0.8f)*(float)enc_diff_sum[1];
    	enc_speed_raw[2] = 0.8f*enc_speed_raw_prev[2] + (1.0f-0.8f)*(float)enc_diff_sum[2];
    	enc_speed_raw[3] = 0.8f*enc_speed_raw_prev[3] + (1.0f-0.8f)*(float)enc_diff_sum[3];

    	enc_speed_raw_prev[0] = enc_speed_raw[0];
    	enc_speed_raw_prev[1] = enc_speed_raw[1];
    	enc_speed_raw_prev[2] = enc_speed_raw[2];
    	enc_speed_raw_prev[3] = enc_speed_raw[3];

    	//4-8 length ring buffer_proc2
    	enc_diff_sum[0] -= enc_diff_tmp[0][e_add_b];
    	enc_diff_sum[1] -= enc_diff_tmp[1][e_add_b];
    	enc_diff_sum[2] -= enc_diff_tmp[2][e_add_b];
    	enc_diff_sum[3] -= enc_diff_tmp[3][e_add_b];

    	e_add_t++;
    	e_add_b++;
    	e_add_t = e_add_t & 0x7;
    	e_add_b = e_add_b & 0x7;

    	//unit conversion
    	pulse2rev();
    	pulse2rot();

    	rev2val();
    	rot2val();
    	//pulse2pos();
    	//pulse2vel();

    	//HAL_DAC_SetValue(&hdac, DAC_CHANNEL_1, DAC_ALIGN_12B_R, 4095);


    	/////Control Logic//////
    	float CMD_pos_calc[4];
    	float CMD_vel_calc[4];
    	float out_vel_diff[4];
    	float err_vel_diff[4];
    	static float err_vel_prev[4] = {0.0f};
    	static float out_vel_prev[4] = {0.0f};
    	float Cout_sgn[4];
    	float CMD_cur_calc[4];
    	int32_t cLimit_flg[4];

    	switch(ctrlMode){
    		case pos_cmd_mode: //m0~m3:_rad
    			CMD_pos_calc[0] = CMD_pos[0];
    			CMD_pos_calc[1] = CMD_pos[1];
    			CMD_pos_calc[2] = CMD_pos[2];
    			CMD_pos_calc[3] = CMD_pos[3];

    			if(sState == homing){
    				static float CMD_pos_prev[4] = {0.0f};
    				CMD_pos_calc[0] = 0.993f *CMD_pos_prev[0] + (1.0f -0.993f)*CMD_pos[0];
    				CMD_pos_calc[1] = 0.993f *CMD_pos_prev[1] + (1.0f -0.993f)*CMD_pos[1];
    				CMD_pos_calc[2] = 0.993f *CMD_pos_prev[2] + (1.0f -0.993f)*CMD_pos[2];
    				CMD_pos_calc[3] = 0.993f *CMD_pos_prev[3] + (1.0f -0.993f)*CMD_pos[3];

    				CMD_pos_prev[0] = CMD_pos_calc[0];
    				CMD_pos_prev[1] = CMD_pos_calc[1];
    				CMD_pos_prev[2] = CMD_pos_calc[2];
    				CMD_pos_prev[3] = CMD_pos_calc[3];
    			}

    			//Position limit without anti-reset-windup
    			//if		(CMD_pos_calc[0] > p_0.plimit_max)	CMD_pos_calc[0] =  p_0.plimit_max;
    			//else if	(CMD_pos_calc[0] < p_0.plimit_min)	CMD_pos_calc[0] =  p_0.plimit_min;
    			if		(CMD_pos_calc[0] > pM0.plimit_max)	CMD_pos_calc[0] =  pM0.plimit_max;
    			else if	(CMD_pos_calc[0] < pM0.plimit_min)	CMD_pos_calc[0] =  pM0.plimit_min;
    			if		(CMD_pos_calc[1] > pM1.plimit_max)	CMD_pos_calc[1] =  pM1.plimit_max;
    			else if	(CMD_pos_calc[1] < pM1.plimit_min)	CMD_pos_calc[1] =  pM1.plimit_min;
    			if		(CMD_pos_calc[2] > pM2.plimit_max)	CMD_pos_calc[2] =  pM2.plimit_max;
    			else if	(CMD_pos_calc[2] < pM2.plimit_min)	CMD_pos_calc[2] =  pM2.plimit_min;
    			if		(CMD_pos_calc[3] > pM3.plimit_max)	CMD_pos_calc[3] =  pM3.plimit_max;
    			else if	(CMD_pos_calc[3] < pM3.plimit_min)	CMD_pos_calc[3] =  pM3.plimit_min;

    			err_pos[0] = CMD_pos_calc[0] - enc_pos[0];
    			err_pos[1] = CMD_pos_calc[1] - enc_pos[1];
    			err_pos[2] = CMD_pos_calc[2] - enc_pos[2];
    			err_pos[3] = CMD_pos_calc[3] - enc_pos[3];
    			//indicator
    			if((-0.1 < err_pos[0])&&(err_pos[0] < 0.1))	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET);   //PIROT LED0 ON
    			else 										HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET); //PIROT LED0 OFF
    			if((-0.1 < err_pos[1])&&(err_pos[1] < 0.1))	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_SET);   //PIROT LED0 ON
    			else 										HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_RESET); //PIROT LED0 OFF
    			if((-0.1 < err_pos[2])&&(err_pos[2] < 0.1))	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_12, GPIO_PIN_SET);   //PIROT LED0 ON
    			else 										HAL_GPIO_WritePin(GPIOA, GPIO_PIN_12, GPIO_PIN_RESET); //PIROT LED0 OFF
    			if((-0.1 < err_pos[3])&&(err_pos[3] < 0.1))	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_SET);   //PIROT LED0 ON
    			else 										HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_RESET); //PIROT LED0 OFF

    			//CMD_vel[0] = p_0.Kp_P * err_pos[0];
    			CMD_vel[0] = pM0.Kp_P * err_pos[0];
    			CMD_vel[1] = pM1.Kp_P * err_pos[1];
    			CMD_vel[2] = pM2.Kp_P * err_pos[2];
    			CMD_vel[3] = pM3.Kp_P * err_pos[3];


    		case vel_cmd_mode: //m0~m2:_rad/s, m3:_mm/s

    			CMD_vel_calc[0] = CMD_vel[0];
    			CMD_vel_calc[1] = CMD_vel[1];
    			CMD_vel_calc[2] = CMD_vel[2];
    			CMD_vel_calc[3] = CMD_vel[3];

    			if(sState == origin){
    				static float CMD_vel_prev[4] = {0.0f};
    				CMD_vel_calc[0] = 0.993f *CMD_vel_prev[0] + (1.0f -0.993f)*CMD_vel[0];
    				CMD_vel_calc[1] = 0.993f *CMD_vel_prev[1] + (1.0f -0.993f)*CMD_vel[1];
    				CMD_vel_calc[2] = 0.993f *CMD_vel_prev[2] + (1.0f -0.993f)*CMD_vel[2];
    				CMD_vel_calc[3] = 0.993f *CMD_vel_prev[3] + (1.0f -0.993f)*CMD_vel[3];

    				CMD_vel_prev[0] = CMD_vel_calc[0];
    				CMD_vel_prev[1] = CMD_vel_calc[1];
    				CMD_vel_prev[2] = CMD_vel_calc[2];
    				CMD_vel_prev[3] = CMD_vel_calc[3];
    			}

    			//Velocity limit without anti-reset-windup
    			//if		(CMD_vel_calc[0] > p_0.vlimit_max)	CMD_vel_calc[0] =  p_0.vlimit_max;
    			//else if	(CMD_vel_calc[0] < p_0.vlimit_min)	CMD_vel_calc[0] =  p_0.vlimit_min;
    			if		(CMD_vel_calc[0] > pM0.vlimit_max)	CMD_vel_calc[0] =  pM0.vlimit_max;
    			else if	(CMD_vel_calc[0] < pM0.vlimit_min)	CMD_vel_calc[0] =  pM0.vlimit_min;
    			if		(CMD_vel_calc[1] > pM1.vlimit_max)	CMD_vel_calc[1] =  pM1.vlimit_max;
    			else if	(CMD_vel_calc[1] < pM1.vlimit_min)	CMD_vel_calc[1] =  pM1.vlimit_min;
    			if		(CMD_vel_calc[2] > pM2.vlimit_max)	CMD_vel_calc[2] =  pM2.vlimit_max;
    			else if	(CMD_vel_calc[2] < pM2.vlimit_min)	CMD_vel_calc[2] =  pM2.vlimit_min;
    			if		(CMD_vel_calc[3] > pM3.vlimit_max)	CMD_vel_calc[3] =  pM3.vlimit_max;
    			else if	(CMD_vel_calc[3] < pM3.vlimit_min)	CMD_vel_calc[3] =  pM3.vlimit_min;

    			err_vel[0] = CMD_vel_calc[0] - enc_speed[0];
    			err_vel[1] = CMD_vel_calc[1] - enc_speed[1];
    			err_vel[2] = CMD_vel_calc[2] - enc_speed[2];
    			err_vel[3] = CMD_vel_calc[3] - enc_speed[3];


    			//P-I control by velocity form
    			/* for test motor
    			err_vel_diff[0] = err_vel[0] - err_vel_prev[0];
    			out_vel_diff[0] = p_0.Kp_V * (err_vel_diff[0] + (p_0.Ki_V * err_vel[0]));
    			CMD_cur[0] = out_vel_diff[0] + out_vel_prev[0];
    			err_vel_prev[0] = err_vel[0];
    			out_vel_prev[0] = CMD_cur[0];
    			*/
    			err_vel_diff[0] = err_vel[0] - err_vel_prev[0];
    			out_vel_diff[0] = pM0.Kp_V * (err_vel_diff[0] + (pM0.Ki_V * err_vel[0]));
    			CMD_cur[0] = out_vel_diff[0] + out_vel_prev[0];
    			err_vel_prev[0] = err_vel[0];
    			out_vel_prev[0] = CMD_cur[0];

    			err_vel_diff[1] = err_vel[1] - err_vel_prev[1];
    			out_vel_diff[1] = pM1.Kp_V * (err_vel_diff[1] + (pM1.Ki_V * err_vel[1]));
    			CMD_cur[1] = out_vel_diff[1] + out_vel_prev[1];
    			err_vel_prev[1] = err_vel[1];
    			out_vel_prev[1] = CMD_cur[1];

    			err_vel_diff[2] = err_vel[2] - err_vel_prev[2];
    			out_vel_diff[2] = pM2.Kp_V * (err_vel_diff[2] + (pM2.Ki_V * err_vel[2]));
    			CMD_cur[2] = out_vel_diff[2] + out_vel_prev[2];
    			err_vel_prev[2] = err_vel[2];
    			out_vel_prev[2] = CMD_cur[2];

    			err_vel_diff[3] = err_vel[3] - err_vel_prev[3];
    			out_vel_diff[3] = pM3.Kp_V * (err_vel_diff[3] + (pM3.Ki_V * err_vel[3]));
    			CMD_cur[3] = out_vel_diff[3] + out_vel_prev[3];
    			err_vel_prev[3] = err_vel[3];
    			out_vel_prev[3] = CMD_cur[3];


    		case cur_cmd_mode: //m0~m3:_A

    			//if(CMD_cur[0] > 0.0f){	CMD_cur_calc[0] = CMD_cur[0] +p_0.Ts_p; Cout_sgn[0] =  1.0f;}
    			//else				 {	CMD_cur_calc[0] = CMD_cur[0] +p_0.Ts_n; Cout_sgn[0] = -1.0f;}
    			if(CMD_cur[0] > 0.0f){	CMD_cur_calc[0] = CMD_cur[0] +pM0.Ts_p; Cout_sgn[0] =  1.0f;}
    			else				 {	CMD_cur_calc[0] = CMD_cur[0] +pM0.Ts_n; Cout_sgn[0] = -1.0f;}
    			if(CMD_cur[1] > 0.0f){	CMD_cur_calc[1] = CMD_cur[1] +pM1.Ts_p; Cout_sgn[1] =  1.0f;}
    			else				 {	CMD_cur_calc[1] = CMD_cur[1] +pM1.Ts_n; Cout_sgn[1] = -1.0f;}
    			if(CMD_cur[2] > 0.0f){	CMD_cur_calc[2] = CMD_cur[2] +pM2.Ts_p; Cout_sgn[2] =  1.0f;}
    			else				 {	CMD_cur_calc[2] = CMD_cur[2] +pM2.Ts_n; Cout_sgn[2] = -1.0f;}
    			if(CMD_cur[3] > 0.0f){	CMD_cur_calc[3] = CMD_cur[3] +pM3.Ts_p; Cout_sgn[3] =  1.0f;}
    			else				 {	CMD_cur_calc[3] = CMD_cur[3] +pM3.Ts_n; Cout_sgn[3] = -1.0f;}

    			//current_limit
    			//if		(CMD_cur_calc[0] > p_0.climit_max){CMD_cur_calc[0] = p_0.climit_max; cLimit_flg[0] =  1;}
    			//else if	(CMD_cur_calc[0] < p_0.climit_min){CMD_cur_calc[0] = p_0.climit_min; cLimit_flg[0] = -1;}
    			if		(CMD_cur_calc[0] > pM0.climit_max){CMD_cur_calc[0] = pM0.climit_max; cLimit_flg[0] =  1;}
    			else if	(CMD_cur_calc[0] < pM0.climit_min){CMD_cur_calc[0] = pM0.climit_min; cLimit_flg[0] = -1;}
    			if		(CMD_cur_calc[1] > pM1.climit_max){CMD_cur_calc[1] = pM1.climit_max; cLimit_flg[1] =  1;}
    			else if	(CMD_cur_calc[1] < pM1.climit_min){CMD_cur_calc[1] = pM1.climit_min; cLimit_flg[1] = -1;}
    			if		(CMD_cur_calc[2] > pM2.climit_max){CMD_cur_calc[2] = pM2.climit_max; cLimit_flg[2] =  1;}
    			else if	(CMD_cur_calc[2] < pM2.climit_min){CMD_cur_calc[2] = pM2.climit_min; cLimit_flg[2] = -1;}
    			if		(CMD_cur_calc[3] > pM3.climit_max){CMD_cur_calc[3] = pM3.climit_max; cLimit_flg[3] =  1;}
    			else if	(CMD_cur_calc[3] < pM3.climit_min){CMD_cur_calc[3] = pM3.climit_min; cLimit_flg[3] = -1;}


    			/*
    			//jerk_limit
    			int32_t jLimit_flg[4] = {0};
    			static float itgCC = 0.0f;
    			float difCC = outCC - itgCC;
    			if		(difCC >  jLimit){	itgCC += jLimit;	jLimit_flg = 1;}
    			else if	(difCC < -jLimit){	itgCC -= jLimit;	jLimit_flg = 1;}
    			else 						itgCC += difCC;
    			//vOUT = Rmotor * itgCC + Eg* enc_speed_f + Eofs; //V
    			*/
    			//CMD_vol[0] = p_0.Re * CMD_cur_calc[0] + p_0.Ke * enc_speed[0] + Cout_sgn[0]*p_0.Vs; //V
    			CMD_vol[0] = pM0.Re * CMD_cur_calc[0] + pM0.Ke * enc_speed[0] + Cout_sgn[0]*pM0.Vs; //V
    			CMD_vol[1] = pM1.Re * CMD_cur_calc[1] + pM1.Ke * enc_speed[1] + Cout_sgn[1]*pM1.Vs; //V
    			CMD_vol[2] = pM2.Re * CMD_cur_calc[2] + pM2.Ke * enc_speed[2] + Cout_sgn[2]*pM2.Vs; //V
    			CMD_vol[3] = pM3.Re * CMD_cur_calc[3] + pM3.Ke * enc_speed[3] + Cout_sgn[3]*pM3.Vs; //V

    		case vol_cmd_mode: //m0~m3:_V
    			//BATTERY Limit
    			if		(CMD_vol[0] >  12.2f)	CMD_vol[0] =  12.2f;
    			else if	(CMD_vol[0] < -12.2f)	CMD_vol[0] = -12.2f;
    			if		(CMD_vol[1] >  12.2f)	CMD_vol[1] =  12.2f;
    			else if	(CMD_vol[1] < -12.2f)	CMD_vol[1] = -12.2f;
    			if		(CMD_vol[2] >  12.2f)	CMD_vol[2] =  12.2f;
    			else if	(CMD_vol[2] < -12.2f)	CMD_vol[2] = -12.2f;
    			if		(CMD_vol[3] >  12.2f)	CMD_vol[3] =  12.2f;
    			else if	(CMD_vol[3] < -12.2f)	CMD_vol[3] = -12.2f;

    			mDrive(M0,CMD_vol[0]);
    			mDrive(M1,CMD_vol[1]);
    			mDrive(M2,CMD_vol[2]);
    			mDrive(M3,CMD_vol[3]);

    	}

    	//++++++++++DEBUG+++++++++++//
    	int16_t dispAB[2];
    	dispAB[0] = (int16_t)(CMD_pos[3] *400.0f)+2048;
    	dispAB[1] = (int16_t)(enc_pos[3] *400.0f)+2048;
    	//dispAB[0] = (int16_t)(CMD_pos[0] *200.0f)+2048;
    	//dispAB[1] = (int16_t)(err_pos[0] *200.0f)+2048;

    	HAL_DAC_SetValue(&hdac, DAC_CHANNEL_1, DAC_ALIGN_12B_R, dispAB[0]);
    	HAL_DAC_SetValue(&hdac, DAC_CHANNEL_2, DAC_ALIGN_12B_R, dispAB[1]);
    	//LL_DAC_ConvertData12RightAligned(DAC1, LL_DAC_CHANNEL_1, (2*(int)vt_cmd)+2048);
    	//LL_DAC_ConvertData12RightAligned(DAC1, LL_DAC_CHANNEL_2, (2*(int)enc_speed_f)+2048);

    	//if(!(HAL_GPIO_ReadPin(B1_GPIO_Port, B1_Pin))){ printf("%.3f\r\n",enc_speed[0]);}
    	//printf("%.3f,%.3f\r\n",CMD_vel[0],enc_speed[0]);

    	//printf("%d,\t%d,\t%f,\t%f,\t%f,\t%f\r\n",CMD_pos[0],current_pos,vt_cmd,enc_speed_f,outCC,vOUT);
    	//printf("%.2f\t%.2f\r\n",vt_cmd,enc_speed_f);
    	//printf("%d\t%d\r\n",(int)CMD_pos[0],(int)current_pos);*/
    }
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_ADC1_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_TIM5_Init();
  MX_TIM8_Init();
  MX_USART3_UART_Init();
  MX_I2C2_Init();
  MX_DAC_Init();
  MX_TIM6_Init();
  /* USER CODE BEGIN 2 */

  //Rotary Encoder Enable
  HAL_TIM_Encoder_Start(&htim2,TIM_CHANNEL_ALL); //For Motor 0
  HAL_TIM_Encoder_Start(&htim3,TIM_CHANNEL_ALL); //For Motor 1
  HAL_TIM_Encoder_Start(&htim4,TIM_CHANNEL_ALL); //For Motor 2
  HAL_TIM_Encoder_Start(&htim5,TIM_CHANNEL_ALL); //For Motor 3

  //PWM ENABLE
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1); //For Motor 0
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2); //For Motor 0

  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3); //For Motor 1
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4); //For Motor 1

  HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_1); //For Motor 2
  HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_2); //For Motor 2

  HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_3); //For Motor 3
  HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_4); //For Motor 3

  //Set PWM Neutral Value
  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 256);
  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 256);
  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, 256);
  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4, 256);
  __HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_1, 256);
  __HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_2, 256);
  __HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_3, 256);
  __HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_4, 256);

  HAL_DAC_Start(&hdac, DAC_CHANNEL_1);
  HAL_DAC_Start(&hdac, DAC_CHANNEL_2);

  //sState = origin;
  ctrlMode = pos_cmd_mode;
  //CMD_pos[0] = 0.0f;
  homing_status.whole = 0;
  HAL_TIM_Base_Start_IT(&htim6);

  printf("stand by...\r\n");

  HAL_Delay(1000);

  //MOTOR ENABLE
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
//#define DEBUG_ON
#ifdef DEBUG_ON
	  // _sState {stand_by,origin,working,error} sState;

	  //float m0deg = (float)enc_pos_raw[0] *pulse2deg_0;
	  //float m0rad = (float)enc_pos_raw[0] *pulse2rad_0;
	  //float m0roll = (float)enc_pos_raw[0] *pulse2roll_0;
	  //float m0rev = (float)enc_speed_raw[0] *pulse2rev_0;
	  GPIO_PinState sstate = HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13);
	  float vout1 = 0.006 * (float)(V_VR[0]-2048);
	  float vout2 = 0.006 * (float)(V_VR[1]-2048);
	  static int32_t toggle = 0;
	  static int32_t update_t = 0;
	  //static float tmp_v = 0.0f;
	  /*
	  if((-0.2<(vout1-tmp_v))&&((vout1-tmp_v)<0.2)){vout2 = tmp_v;}
	  else{vout2 += (vout1-tmp_v);}
	  tmp_v=vout2;
*/

	  pM0.vlimit_min=-0.2f;
	  pM0.vlimit_max= 0.2f;
	  pM1.vlimit_min=-0.6f;
	  pM1.vlimit_max= 0.6f;
	  pM2.vlimit_min=-4.0f;
	  pM2.vlimit_max= 4.0f;
	  pM3.vlimit_min=-100.0f;
	  pM3.vlimit_max= 100.0f;

	  vout1 = (int32_t)vout1;
	  vout2 = (int32_t)vout2;
	  if(!V_BAT_check()){
		  if(sstate == GPIO_PIN_SET){
			  //enc_pos_raw[3] = 0;
			  //HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET);
			  //ctrlMode = pos_cmd_mode;
			  //CMD_cur[3] = 0.0f;
			  //CMD_vol[3] = 10.0f;
			  //mDrive(M0,vout1);
			  //mDrive(M1,vout2);
			  //CMD_vel[0]=vout1;
			  CMD_pos[1] = 0.0f;
			  update_t = 1;
		  }
		  else{
			  if(update_t){
				  if(toggle){toggle = 0;}
				  else{toggle = 1;}
			  }
			  update_t = 0;
			  //mDrive(M2,vout1);
			  //mDrive(M3,vout2);
			  //ctrlMode = cur_cmd_mode;
			  //CMD_cur[0] = 0.0f;
			  //CMD_cur[1] = 0.0f;
			  //HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET);
			  /*if(toggle){
				  CMD_pos[0]=0.5f;
			  }
			  else{
				  CMD_pos[0]=-0.5f;
			  }*/
			  CMD_pos[1] = -M_PI_2;
			  //printf("%ld,%.4f,%.4f\r\n",HAL_GetTick(),enc_speed[2],enc_speed[3]);
		  }
	  }
	  //printf("BATTERY = %.3f, Vout1 =%.3f, Vout2 = %.3f, rad = %.3f, enc = %ld \r\n",V_BAT_act, vout1, vout2, m0rad, enc_pos_raw[0]);
	  //printf("%.3f, %.3f, %.3f, %.3f, BATT = %.3f \r\n",enc_speed_raw[0], enc_speed_raw[1], enc_speed_raw[2], enc_speed_raw[3], V_BAT_act);
	  //printf("%d, %d, %d, %d, BATT = %.3f \r\n",enc_diff_raw[0], enc_diff_raw[1], enc_diff_raw[2], enc_diff_raw[3], V_BAT_act);
	  //printf("%ld,\t%.3f\r\n",enc_pos_raw[1], enc_pos[1]);
	  //printf("BATTERY = %.3f, vout1 = %.3f, roll =%.3f, rev/sec = %.3f \r\n",V_BAT_act, vout1,m0roll, m0rev);
	  printf("%ld,%.3f,%.8f\r\n",HAL_GetTick(),CMD_pos[1],CMD_pos[0]);
	  HAL_Delay(2);
#else

//	  static int32_t sigOrgn = 0;
//	  static int32_t sigOrgn_f = 0;
	  static int32_t tick_prev_sw;
	  static int32_t tick_prev_M3;
	  static int32_t tick_prev_LED;
	  static uint32_t LED_state_cnt = 0;
	  static int32_t B1_state_prev;
//	  int32_t B1_presstime;
	  float vout1 = 0.006 * (float)(V_VR[0]-2048);
	  static float vout2; // = 0.006 * (float)(V_VR[1]-2048);
	  static float tmp_v = 0.0f;
	  float pos_adjust[4];


	  switch(sState){
	  	  case stand_by:
	  		  if((HAL_GetTick()-tick_prev_LED) >500){
	  			  tick_prev_LED = HAL_GetTick();
	  			  LED_state_cnt++;
	  		  }
	  		  if(LED_state_cnt &0x01){HAL_DAC_SetValue(&hdac, DAC_CHANNEL_2, DAC_ALIGN_12B_R, 4095);}
	  		  else					 {HAL_DAC_SetValue(&hdac, DAC_CHANNEL_2, DAC_ALIGN_12B_R,    0);}

	  		  if(!(HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13))){
	  			  if(B1_state_prev) tick_prev_sw = HAL_GetTick();
	  			  if((HAL_GetTick()-tick_prev_sw) >1000){
	  				  sState = origin;
	  				  //origin_evt = 0x0c; //skip
	  				  HAL_DAC_SetValue(&hdac, DAC_CHANNEL_2, DAC_ALIGN_12B_R, 4095);
	  				  break;
	  			  }
	  		  }
	  		  B1_state_prev = HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13);
	  		break;

	  	case origin:
	  		switch(origin_evt){
	  			  case 0x00: //m0 Return to origin
	  				    ctrlMode = vel_cmd_mode;
	  			  	  	CMD_vel[0] = -0.3f;
			  			if(homing_status.idv.m0 == 0x01){origin_evt = 0x01;}
	  			  		break;
	  			  case 0x01:
	  				   	CMD_vel[0] =  0.1f;
	  			  	  	if((enc_pos_raw[0] - pos_tmp[0]) > (20000)){origin_evt= 0x02;}

	  			  	  	break;
	  			  case 0x02:
	  			  	  	CMD_vel[0] = -0.08f;
	  			  	  	if(homing_status.idv.m0 == 0x03){origin_evt = 0x03;}
	  			  	  	break;
	  			  case 0x03:
	  			  	  	CMD_vel[0] = 0.0f;
	  			  	  	HAL_Delay(2000);
	  			  	  	origin_evt = 0x04;
	  			  	  	break;

	  			  case 0x04: //m1 Return to origin
	  				  	CMD_vel[1] = -0.3f;
			  			if(homing_status.idv.m1 == 0x01){origin_evt = 0x05;}
	  				  	break;
	  			  case 0x05:
	  				   	CMD_vel[1] = 0.1f;
	  			  	  	if((enc_pos_raw[1] - pos_tmp[1]) > (10000)){origin_evt= 0x06;}

	  			  	  	break;
	  			  case 0x06:
	  			  	  	CMD_vel[1] = -0.05f;
	  			  	  	if(homing_status.idv.m1 == 0x03){origin_evt = 0x07;}
	  			  	  	break;
	  			  case 0x07:
	  			  	  	CMD_vel[1] = 0.0f;
	  			  	  	HAL_Delay(2000);
	  			  	  	ctrlMode = pos_cmd_mode;
	  			  	  	sState = homing;
	  			  	  	homing_evt = 0x00;
	  			  	  	break;

	  			  case 0x08: //m2 Return to origin
	  				    ctrlMode = vel_cmd_mode;
	  				    CMD_vel[0] =  0.0f;
	  				    CMD_vel[0] =  0.0f;
	  			  	  	CMD_vel[2] = -0.5f;
			  			if(homing_status.idv.m2 == 0x01){origin_evt = 0x09;}
	  			  		break;
	  			  case 0x09:
	  				   	CMD_vel[2] = 0.5f;
	  			  	  	if((enc_pos_raw[2] - pos_tmp[2]) > (20000)){origin_evt= 0x0a;}
	  			  	  	break;
	  			  case 0x0a:
	  			  	  	CMD_vel[2] = -0.1f;
	  			  	  	if(homing_status.idv.m2 == 0x03){origin_evt = 0x0b;}
	  			  	  	break;
	  			  case 0x0b:
	  			  	  	CMD_vel[2] = 0.0f;
	  			  	  	HAL_Delay(2000);
	  			  	  	ctrlMode = pos_cmd_mode;
	  			  	  	sState = homing;
	  			  	  	homing_evt = 0x01;
	  			  	  	break;

	  			  case 0x0c: //m3 Return to origin
	  				    ctrlMode = vel_cmd_mode;
	  				    CMD_vel[0] =  0.0f;
	  				    CMD_vel[1] =  0.0f;
	  				    CMD_vel[2] =  0.0f;
	  			  	  	CMD_vel[3] = 10.0f;
			  			if((-0.8 > CMD_cur[3])||(CMD_cur[3] > 0.8)){
			  				if((HAL_GetTick() -tick_prev_M3)>1000){
			  					pos_tmp[3] = enc_pos_raw[3];
			  					origin_evt = 0x0d;
			  				}
			  			}
			  			else{
			  				tick_prev_M3 = HAL_GetTick();
			  			}
	  			  		break;
	  			  case 0x0d:
	  				    CMD_vel[3] = -10.0f;
	  			  	  	if((enc_pos_raw[3] - pos_tmp[3]) < (-20000)){origin_evt= 0x0e;}
	  			  	  	break;
	  			  case 0x0e:
	  			  	  	CMD_vel[3] = 10.0f;
			  			if((-1.0 > CMD_cur[3])||(CMD_cur[3] > 1.0)){
			  				if((HAL_GetTick() -tick_prev_M3)>1000){
			  					enc_setRadPos(M3,500.0f);
			  					origin_evt = 0x0f;
			  				}
			  			}
			  			else{
			  				tick_prev_M3 = HAL_GetTick();
			  			}
	  			  	  	break;
	  			  case 0x0f:
	  			  	  	CMD_vel[3] = 0.0f;
	  			  	  	HAL_Delay(2000);
	  			  	  	ctrlMode = pos_cmd_mode;
	  			  	  	sState = homing;
	  			  	  	homing_evt = 0x02;
	  			  	  	break;
  			  }

	  		break;

	  	case homing:
	  		switch(homing_evt){
	  			case 0x00: //m0 & m1 Move to home position
	  				//p_0.vlimit_min=-1.0f;
	  				//p_0.vlimit_max= 1.0f;//vel_limit_mode(state? mode?)
	  				pM0.vlimit_min=-0.6f;
	  				pM0.vlimit_max= 0.6f;
	  				pM1.vlimit_min=-0.4f;
	  				pM1.vlimit_max= 0.4f;

	  				CMD_pos[0] = home_pos[0];
	  				CMD_pos[1] = home_pos[1];

	  				pos_adjust[0] = home_pos[0]-enc_pos[0];
	  				pos_adjust[1] = home_pos[1]-enc_pos[1];

	  				if((-0.1 < pos_adjust[0])&&(pos_adjust[0] < 0.1)){
	  					if((-0.1 < pos_adjust[1])&&(pos_adjust[1] < 0.1)){
	  						HAL_Delay(2000);
	  						sState = origin;
	  						origin_evt = 0x08;
	  						//sState = working;
	  					}
	  				}
	  				break;

	  			case 0x01: //m2 Move to home position
	  				pM2.vlimit_min=-1.0f;
	  				pM2.vlimit_max= 1.0f;

	  				CMD_pos[2] = home_pos[2];
	  				pos_adjust[2] = home_pos[2]-enc_pos[2];
	  				if((-0.1 < pos_adjust[2])&&(pos_adjust[2] < 0.1)){
	  					HAL_Delay(2000);
	  					sState = origin;
	  					origin_evt = 0x0c;
	  					//sState = working;
	  				}
	  				break;

	  			case 0x02: //m3 Move to home position
	  				pM3.vlimit_min=-100.0f;
	  				pM3.vlimit_max= 100.0f;

	  				CMD_pos[3] = home_pos[3];
	  				pos_adjust[3] = home_pos[3]-enc_pos[3];
	  				if((-0.1 < pos_adjust[3])&&(pos_adjust[3] < 0.1)){
	  					HAL_Delay(2000);
	  					sState = working;
	  				}
	  				break;
	  		}

		   break;

	   case working:
		   //working parameter setting
		   //p_0.vlimit_min=-9.0f;
		   //p_0.vlimit_max= 9.0f;
		   /*pM0.vlimit_min=-9.0f;
		   pM0.vlimit_max= 9.0f;
		   pM1.vlimit_min=-9.0f;
		   pM1.vlimit_max= 9.0f;
		   pM2.vlimit_min=-9.0f;
		   pM2.vlimit_max= 9.0f;
		   pM3.vlimit_min=-9.0f;
		   pM3.vlimit_max= 9.0f;*/

		   if((-0.2<(vout1-tmp_v))&&((vout1-tmp_v)<0.2)){vout2 = tmp_v;}
		   else{vout2 += (vout1-tmp_v);}
		   tmp_v=vout2;
		   //CMD_pos[0] = vout2;
		   break;

	   case error:
		   HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET); //~SD DISABLE
		   if((HAL_GetTick()-tick_prev_LED) >250){
	  			  tick_prev_LED = HAL_GetTick();
	  			  LED_state_cnt++;
		   }
		   if(LED_state_cnt &0x01){HAL_DAC_SetValue(&hdac, DAC_CHANNEL_2, DAC_ALIGN_12B_R, 4095);}
		   else				      {HAL_DAC_SetValue(&hdac, DAC_CHANNEL_2, DAC_ALIGN_12B_R,    0);}

		   if(!V_BAT_check()){
			   if(!(HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13))){
	  			  if(B1_state_prev) tick_prev_sw = HAL_GetTick();
	  			  if((HAL_GetTick()-tick_prev_sw) >2000){
	  				  sState = homing;
	  				  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET); //~SD ENABLE
	  				  HAL_DAC_SetValue(&hdac, DAC_CHANNEL_2, DAC_ALIGN_12B_R, 4095);
	  				  break;
	  			  }
	  		  }
			  B1_state_prev = HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13);
		   }
		   break;
	  }

	  if(V_BAT_check()){sState = error;}
	  printf("%ld,%.3f,%.3f\r\n",HAL_GetTick(),CMD_pos[0],enc_pos[0]);
	  HAL_Delay(2);
#endif
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = ENABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = ENABLE;
  hadc1.Init.NbrOfDiscConversion = 1;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 3;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_14;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_15CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_6;
  sConfig.Rank = 2;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_7;
  sConfig.Rank = 3;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief DAC Initialization Function
  * @param None
  * @retval None
  */
static void MX_DAC_Init(void)
{

  /* USER CODE BEGIN DAC_Init 0 */

  /* USER CODE END DAC_Init 0 */

  DAC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN DAC_Init 1 */

  /* USER CODE END DAC_Init 1 */

  /** DAC Initialization
  */
  hdac.Instance = DAC;
  if (HAL_DAC_Init(&hdac) != HAL_OK)
  {
    Error_Handler();
  }

  /** DAC channel OUT1 config
  */
  sConfig.DAC_Trigger = DAC_TRIGGER_NONE;
  sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
  if (HAL_DAC_ConfigChannel(&hdac, &sConfig, DAC_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }

  /** DAC channel OUT2 config
  */
  if (HAL_DAC_ConfigChannel(&hdac, &sConfig, DAC_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN DAC_Init 2 */

  /* USER CODE END DAC_Init 2 */

}

/**
  * @brief I2C2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C2_Init(void)
{

  /* USER CODE BEGIN I2C2_Init 0 */

  /* USER CODE END I2C2_Init 0 */

  /* USER CODE BEGIN I2C2_Init 1 */

  /* USER CODE END I2C2_Init 1 */
  hi2c2.Instance = I2C2;
  hi2c2.Init.ClockSpeed = 100000;
  hi2c2.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c2.Init.OwnAddress1 = 0;
  hi2c2.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c2.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c2.Init.OwnAddress2 = 0;
  hi2c2.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c2.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C2_Init 2 */

  /* USER CODE END I2C2_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 32-1;
  htim1.Init.CounterMode = TIM_COUNTERMODE_CENTERALIGNED1;
  htim1.Init.Period = 512;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 65535;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI1;
  sConfig.IC1Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 0;
  sConfig.IC2Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 0;
  if (HAL_TIM_Encoder_Init(&htim2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 0;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI1;
  sConfig.IC1Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 0;
  sConfig.IC2Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 0;
  if (HAL_TIM_Encoder_Init(&htim3, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 0;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 65535;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI1;
  sConfig.IC1Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 0;
  sConfig.IC2Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 0;
  if (HAL_TIM_Encoder_Init(&htim4, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */

}

/**
  * @brief TIM5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM5_Init(void)
{

  /* USER CODE BEGIN TIM5_Init 0 */

  /* USER CODE END TIM5_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM5_Init 1 */

  /* USER CODE END TIM5_Init 1 */
  htim5.Instance = TIM5;
  htim5.Init.Prescaler = 0;
  htim5.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim5.Init.Period = 65535;
  htim5.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim5.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI1;
  sConfig.IC1Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 0;
  sConfig.IC2Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 0;
  if (HAL_TIM_Encoder_Init(&htim5, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim5, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM5_Init 2 */

  /* USER CODE END TIM5_Init 2 */

}

/**
  * @brief TIM6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM6_Init(void)
{

  /* USER CODE BEGIN TIM6_Init 0 */

  /* USER CODE END TIM6_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM6_Init 1 */

  /* USER CODE END TIM6_Init 1 */
  htim6.Instance = TIM6;
  htim6.Init.Prescaler = 84-1;
  htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim6.Init.Period = 1000-1;
  htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM6_Init 2 */

  /* USER CODE END TIM6_Init 2 */

}

/**
  * @brief TIM8 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM8_Init(void)
{

  /* USER CODE BEGIN TIM8_Init 0 */

  /* USER CODE END TIM8_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM8_Init 1 */

  /* USER CODE END TIM8_Init 1 */
  htim8.Instance = TIM8;
  htim8.Init.Prescaler = 30-1;
  htim8.Init.CounterMode = TIM_COUNTERMODE_CENTERALIGNED1;
  htim8.Init.Period = 512;
  htim8.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim8.Init.RepetitionCounter = 0;
  htim8.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim8) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim8, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim8) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim8, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim8, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim8, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim8, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim8, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim8, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM8_Init 2 */

  /* USER CODE END TIM8_Init 2 */
  HAL_TIM_MspPostInit(&htim8);

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1|GPIO_PIN_2, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_12|GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin_Pin */
  GPIO_InitStruct.Pin = B1_Pin_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_Pin_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : PC0 PC1 PC2 PC3 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PC5 */
  GPIO_InitStruct.Pin = GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PB0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PB1 PB2 */
  GPIO_InitStruct.Pin = GPIO_PIN_1|GPIO_PIN_2;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PB12 PB13 PB15 */
  GPIO_InitStruct.Pin = GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PB14 */
  GPIO_InitStruct.Pin = GPIO_PIN_14;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PA12 PA15 */
  GPIO_InitStruct.Pin = GPIO_PIN_12|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
