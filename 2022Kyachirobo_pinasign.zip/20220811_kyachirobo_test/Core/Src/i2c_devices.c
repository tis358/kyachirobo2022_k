/*
 * i2c_devices.c
 *
 *  Created on: 2022/12/19
 *      Author: tis35
 */

#include "main.h"
#include <stdio.h>
#include "i2c_devices.h"

extern I2C_HandleTypeDef hi2c2;

uint8_t WII_CONTROLLER_ADDRESS = 0x52 << 1;//0xa4
int start_tick = 0;
bool wii_verbose = false;


/*
 * @brief send cmd to wii classic controller pro
 * @param uint8_t address address you want to send signal
 * @param uint8_t command
 * @retval None
 */
void send_sig_to_controller(uint8_t address, uint8_t cmd){
	uint8_t cmd_concat[2] = {address, cmd};
	bool is_HAL_OK = false;
	//Dont use HAL_I2C_Maste_Transmit
	uint8_t buf[1] = {cmd};
	while(!is_HAL_OK){
		int wii_remocon_response = HAL_I2C_Mem_Write(&hi2c2, WII_CONTROLLER_ADDRESS, address, I2C_MEMADD_SIZE_8BIT, buf, 1, 100);
		if(wii_remocon_response == HAL_OK){
			is_HAL_OK = true;
			if(wii_verbose){printf("controller send success addr:%#2x, cmd:%#2x\n", address, cmd);}
		}else{
			printf("controller send failed. code : %x\n", wii_remocon_response);
		}
		HAL_Delay(250);
	}
	HAL_Delay(15);
}


bool is_buttonA_hold = false;
bool is_buttonB_hold = false;
bool is_buttonX_hold = false;
bool is_buttonY_hold = false;
bool is_buttonR_hold = false;
bool is_buttonL_hold = false;
bool is_buttonZR_hold = false;
bool is_buttonZL_hold = false;
bool is_buttonDU_hold = false;
bool is_buttonDD_hold = false;
bool is_buttonDL_hold = false;
bool is_buttonDR_hold = false;
bool is_buttonPlus_hold = false;
bool is_buttonMinus_hold = false;
bool is_buttonHome_hold = false;

// For example, when you want to use function in main header, add prototype definition in main header
void state_change(){
	if(buttonA && !is_buttonA_hold){
		//called once when buttonA pushed
		is_buttonA_hold = true;
	}else if(!buttonA && is_buttonA_hold){
		//called once when buttonA released
		is_buttonA_hold = false;
	}

	if(buttonB && !is_buttonB_hold){
		//called once when buttonB pushed
		is_buttonB_hold = true;
	}else if(!buttonB && is_buttonB_hold){
		//called once when buttonB released
		is_buttonB_hold = false;
	}

	if(buttonX && !is_buttonX_hold){
		//called once when buttonX pushed
		is_buttonX_hold = true;
	}else if(!buttonX && is_buttonX_hold){
		//called once when buttonX released
		is_buttonX_hold = false;
	}

	if(buttonY && !is_buttonY_hold){
		//called once when buttonY pushed
		is_buttonY_hold = true;
	}else if(!buttonY && is_buttonY_hold){
		//called once when buttonY released
		is_buttonY_hold = false;
	}

	if(buttonR && !is_buttonR_hold){
		//called once when buttonR pushed
		is_buttonR_hold = true;
	}else if(!buttonR && is_buttonR_hold){
		//called once when buttonR released
		is_buttonR_hold = false;
	}

	if(buttonL && !is_buttonL_hold){
		//called once when buttonL pushed
		is_buttonL_hold = true;
	}else if(!buttonL && is_buttonL_hold){
		//called once when buttonL released
		is_buttonL_hold = false;
	}

	if(buttonZR && !is_buttonZR_hold){
		//called once when buttonZR pushed
		is_buttonZR_hold = true;
	}else if(!buttonZR && is_buttonZR_hold){
		//called once when buttonZR released
		is_buttonZR_hold = false;
	}

	if(buttonZL && !is_buttonZL_hold){
		//called once when buttonZL pushed
		is_buttonZL_hold = true;
	}else if(!buttonZL && is_buttonZL_hold){
		//called once when buttonZL released
		is_buttonZL_hold = false;
	}

	if(buttonDU && !is_buttonDU_hold){
		//called once when buttonDU pushed
		is_buttonDU_hold = true;
	}else if(!buttonDU && is_buttonDU_hold){
		//called once when buttonDU released
		is_buttonDU_hold = false;
	}

	if(buttonDD && !is_buttonDD_hold){
		//called once when buttonDD pushed
		is_buttonDD_hold = true;
	}else if(!buttonDD && is_buttonDD_hold){
		//called once when buttonDD released
		is_buttonDD_hold = false;
	}

	if(buttonDL && !is_buttonDL_hold){
		//called once when buttonDL pushed
		is_buttonDL_hold = true;
	}else if(!buttonDL && is_buttonDL_hold){
		//called once when buttonDL released
		is_buttonDL_hold = false;
	}

	if(buttonDR && !is_buttonDR_hold){
		//called once when buttonDR pushed
		is_buttonDR_hold = true;
	}else if(!buttonDR && is_buttonDR_hold){
		//called once when buttonDR released
		is_buttonDR_hold = false;
	}

	if(buttonPlus && !is_buttonPlus_hold){
		//called once when buttonPlus pushed
		is_buttonPlus_hold = true;
	}else if(!buttonPlus && is_buttonPlus_hold){
		//called once when buttonPlus released
		is_buttonPlus_hold = false;
	}

	if(buttonMinus && !is_buttonMinus_hold){
		//called once when buttonMinus pushed
		is_buttonMinus_hold = true;
	}else if(!buttonMinus && is_buttonMinus_hold){
		//called once when buttonMinus released
		is_buttonMinus_hold = false;
	}

	if(buttonHome && !is_buttonHome_hold){
		//called once when buttonHome pushed
		is_buttonHome_hold = true;
	}else if(!buttonHome && is_buttonHome_hold){
		//called once when buttonHome released
		is_buttonHome_hold = false;
	}
}

/*
 * @brief initialize wii classic controller pro
 * @params None
 * @retval None
 */
void init_Wii_controller(){
	HAL_I2C_DeInit(&hi2c2);
	HAL_I2C_Init(&hi2c2);
	HAL_Delay(100);
	start_tick = HAL_GetTick();
	send_sig_to_controller(0xf0, 0x55);
	send_sig_to_controller(0xfb, 0x00);
	/*
	uint8_t state = 0x00;
	HAL_I2C_Mem_Read(&hi2c2, WII_CONTROLLER_ADDRESS, 0xf0, I2C_MEMADD_SIZE_8BIT, state, 1, HAL_TIMEOUT);
	printf("%x", state);
	*/
}

/*
 * @brief get wii classic controller pro state every 50ms(=20hz). You have to insert this in main loop.
 * @params None
 * @retval None(global variables will be changed)
 */
void get_Wii_Controller_State(){
	int WII_CONTROLLER_BUFFER_LEN = 6;
	uint8_t read_buffer[WII_CONTROLLER_BUFFER_LEN];
	if(HAL_GetTick() - start_tick >= 50){
		send_sig_to_controller(0x00, 0x00);
		HAL_Delay(15);
		if (HAL_I2C_Master_Receive(&hi2c2, WII_CONTROLLER_ADDRESS, read_buffer, WII_CONTROLLER_BUFFER_LEN, HAL_TIMEOUT) == HAL_OK){
			printf("\n");
			for(int i = 0; i < WII_CONTROLLER_BUFFER_LEN; i++){
				if(wii_verbose){printf(" %#02x |", read_buffer[i]);}
			}
			if(read_buffer[0] & 0x80){
				joyRX = 0x10;
			}else{
				joyRX = 0;
			}
			if(read_buffer[0] & 0x80){
				joyRX = 0x10;
			}else{
				joyRX = 0;
			}
			if(read_buffer[0] & 0x40){joyRX += 0x08;}
			if(read_buffer[1] & 0x80){joyRX += 0x04;}
			if(read_buffer[1] & 0x40){joyRX += 0x02;}
			if(read_buffer[1] & 0x80){joyRX += 0x01;}

			joyRY = read_buffer[2] & 0x1F;
			joyLX = read_buffer[0] & 0x3F;
			joyLY = read_buffer[1] & 0x3F;

			if(read_buffer[4] & 0x80) {buttonDR = 0;}
			else{buttonDR = 1;}

			if(read_buffer[4] & 0x40) {
				buttonDD = 0;
			} else {
				buttonDD = 1;
			}
			if(read_buffer[4] & 0x20) {
				buttonL = 0;
			} else {
				buttonL = 1;
			}
			if(read_buffer[4] & 0x10) {
				buttonMinus = 0;
			} else {
				buttonMinus = 1;
			}
			if(read_buffer[4] & 0x08) {
				buttonHome = 0;
			} else {
				buttonHome = 1;
			}
			if(read_buffer[4] & 0x04) {
				buttonPlus = 0;
			} else {
				buttonPlus = 1;
			}
			if(read_buffer[4] & 0x02) {
				buttonR = 0;
			} else {
				buttonR = 1;
			}
			if(read_buffer[5] & 0x80) {
				buttonZL = 0;
			} else {
				buttonZL = 1;
			}
			if(read_buffer[5] & 0x40) {
				buttonB = 0;
			} else {
				buttonB = 1;
			}
			if(read_buffer[5] & 0x20) {
				buttonY = 0;
			} else {
				buttonY = 1;
			}
			if(read_buffer[5] & 0x10) {
				buttonA = 0;
			} else {
				buttonA = 1;
			}
			if(read_buffer[5] & 0x08) {
				buttonX = 0;
			} else {
				buttonX = 1;
			}
			if(read_buffer[5] & 0x04) {
				buttonZR = 0;
			} else {
				buttonZR = 1;
			}
			if(read_buffer[5] & 0x02) {
				buttonDL = 0;
			} else {
				buttonDL = 1;
			}
			if(read_buffer[5] & 0x01) {
				buttonDU = 0;
			} else {
				buttonDU = 1;
			}
			if(wii_verbose){
				printf("controller state\n");
				printf("RX : %d, RY : %d\n", joyRX, joyRY);
				printf("LX : %d, LY : %d\n", joyLX, joyLY);
				printf(" A : %d,  B : %d,  X : %d,  Y : %d\n", buttonA, buttonB, buttonX, buttonY);
				printf(" R : %d,  L : %d, ZR : %d, ZL : %d\n", buttonR, buttonL, buttonZR, buttonZL);
				printf("DU : %d, DD : %d, DL : %d, DR : %d\n", buttonDU, buttonDD, buttonDL, buttonDR);
				printf("plus : %d, minus : %d, home : %d\n", buttonPlus, buttonMinus, buttonHome);
			}
			/*
			// print 16x16 binaries
			printf("    ||");
			for(int i = 0; i < 16; i++){
				printf(" %02x |", i);
			}
			printf("\n");
			for(int i=0;i<17;i++){
				printf("-----");
			}
			printf("\n");
			for(int i1=0;i1<16;i1++){
				printf(" %02x ||", i1);
				for(int i2=0;i2<16;i2++){
					printf(" %02x |", read_buffer[i1*16+i2]);
				}
				printf("\n");
			}
			*/
			start_tick = HAL_GetTick();
		}
		state_change();
	}
}

/* appendix
 * when you want to communicate with other device via uart, this code may help.

char get_serial(){
	uint8_t buffer[256];
	HAL_StatusTypeDef s;
	s = HAL_UART_Receive(&huart3, buffer, 32, 200);
	if (s == HAL_OK)
	{
	  printf("UART time out\r\n");
	}
	// bug niyori gyaku(honmaka?)
	else if (s == HAL_TIMEOUT)
	{
	  printf("catch %s\r\n", buffer);
	  return buffer;
	}
	return "0";
}

cont_order controller_decoder(){
	cont_order ret;
	int str_pointer = 0;
	char str[32] = "a";//;get_serial();
	HAL_UART_Receive(&huart2, str, 32, 3000);

	while(str[str_pointer] != ')'){
	//while(*(str + str_pointer) != ')'){
		switch(str[str_pointer]){
		case '\'':
			ret.order_id = str[str_pointer+1];
			str_pointer += 3;
			break;
		case 'x':
			ret.x = get_num_from_str(str, str_pointer);
			break;
		case 'y':
			ret.y = get_num_from_str(str, str_pointer);
			break;
		case 'z':
			ret.z = get_num_from_str(str, str_pointer);
			break;
		}
		str_pointer++;
	}
	return ret;
}

void test_encoder(char* encoded){
	cont_order c = controller_decoder(encoded);
	printf("order %c %d, %d, %d\r\n", c.order_id, c.x, c.y, c.z);
}
*/



