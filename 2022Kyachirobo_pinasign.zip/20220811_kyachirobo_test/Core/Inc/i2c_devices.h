/*
 * i2c_devices.h
 *
 *  Created on: 2022/12/19
 *      Author: tis35
 */

#ifndef INC_I2C_DEVICES_H_
#define INC_I2C_DEVICES_H_

// I2C address of classic controller
#define CLASSIC_ADDR     0x52  // 0x52 << 1
#define CLASSIC_REGADDR  0x40  //
#define CLASSIC_READLEN  0x06  //

#define PCA9865_ADDR	 0x40 // 0x40 << 1

#define I2C_ACK 0
#define I2C_READ_DELAY  10

// controller states variables
unsigned char joyRX, joyRY, joyLX, joyLY;
bool buttonA, buttonB, buttonX,
        buttonY, buttonR, buttonL,
        buttonZR, buttonZL, buttonDU,
        buttonDD, buttonDL, buttonDR,
        buttonPlus, buttonMinus, buttonHome;

void send_sig_to_controller(uint8_t address, uint8_t cmd);
void init_Wii_controller();
void get_Wii_Controller_State();


#endif /* INC_I2C_DEVICES_H_ */
